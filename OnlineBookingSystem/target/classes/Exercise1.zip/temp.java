import java.util.Scanner;

public class temp
{
	public static void main(String[] args) 
{ 
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	int b=sc.nextInt();
	int sum=a+b;
	int sub=a-b;
	int mul=a*b;
	int div=a/b;
	System.out.println("Sum is :"+sum);
	System.out.println("Substraction is :"+sub);
	System.out.println("Multiplication is :"+mul);
	System.out.println("Division is :"+div);
}
}
